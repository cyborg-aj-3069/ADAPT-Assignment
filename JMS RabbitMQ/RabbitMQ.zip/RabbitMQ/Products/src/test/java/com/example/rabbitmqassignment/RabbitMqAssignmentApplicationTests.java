package com.example.rabbitmqassignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RabbitMqAssignmentApplicationTests {

    @Test
    void contextLoads() {
    }

}

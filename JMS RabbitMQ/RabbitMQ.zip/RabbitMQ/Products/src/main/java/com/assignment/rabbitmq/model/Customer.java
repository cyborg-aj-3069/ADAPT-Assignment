package com.assignment.rabbitmq.model;

import java.io.Serializable;

public class Customer implements Serializable {

	private static final long serialVersionUID = 1L;
	private String FirstName;
    private String LastName;

    public Customer() {
    }
    
    

	public Customer(String firstName, String lastName) {
		super();
		FirstName = firstName;
		LastName = lastName;
	}



	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}

	public void setLastName(String lastName) {
		LastName = lastName;
	}

    
}

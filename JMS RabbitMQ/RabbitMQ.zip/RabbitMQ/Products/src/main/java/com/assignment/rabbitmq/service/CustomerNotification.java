package com.assignment.rabbitmq.service;

import com.assignment.rabbitmq.RabbitMQConfiguration;
import com.assignment.rabbitmq.model.Customer;
import com.assignment.rabbitmq.repository.CustomerRepository;

import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CustomerNotification {

    @Autowired
    CustomerRepository customerRepo;

    @RabbitListener(queues = RabbitMQConfiguration.queueName)
    public void consumeMessage(Customer customer){
        customerRepo.save(customer);
        System.out.println("Customer successfully added");
    }
}

let search = (...array)=>
{ 
num =array[2];
console.log(num)
}

search(5,5,6,4,0);
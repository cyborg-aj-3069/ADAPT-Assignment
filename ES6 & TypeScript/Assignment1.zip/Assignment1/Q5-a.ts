
let add =function(a=15,b=10)
{
  console.log(a+b);
};
add();
add(20,20);
add(55);

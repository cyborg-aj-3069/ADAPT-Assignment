const a =5
a=6;
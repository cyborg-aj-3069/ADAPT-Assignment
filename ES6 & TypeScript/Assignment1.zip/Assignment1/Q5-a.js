var add = function (a, b) {
    if (a === void 0) { a = 15; }
    if (b === void 0) { b = 10; }
    console.log(a + b);
};
add();
add(20, 20);
add(55);

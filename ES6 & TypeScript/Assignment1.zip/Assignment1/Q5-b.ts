let arrFrnd = ["Abhi","Aj","Golu"];
let UserFriends = function(a="Aman", b= arrFrnd)
{
  console.log("User :" + a +" "+" Friends :" + b);
};
UserFriends();
UserFriends("Abhishek");
UserFriends("Abhishek",["Mukesh","Bala","Vinnu"]);
var Organization = {
    name: 'Aman',
    Address: {
        city: 'Bangalore',
        street: 'Agram',
        Pincode: 560007
    }
};
var Ret_Pin = Organization.Address.Pincode;
console.log(Ret_Pin);

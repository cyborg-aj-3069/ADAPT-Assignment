var search = function () {
    var array = [];
    for (var _i = 0; _i < arguments.length; _i++) {
        array[_i] = arguments[_i];
    }
    num = array[2];
    console.log(num);
};
search(5, 5, 6, 4, 0);

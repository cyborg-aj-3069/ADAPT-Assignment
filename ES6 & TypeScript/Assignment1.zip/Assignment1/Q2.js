var num = 1;
if (num == 1) {
    var a = 5;
}
console.log(a); //out of the scope 

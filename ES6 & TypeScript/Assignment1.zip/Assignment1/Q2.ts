var num = 1
if(num==1){
let a = 5;
}
console.log(a);//out of the scope 